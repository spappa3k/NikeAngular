import { Component } from '@angular/core';

@Component({
  selector: 'app-home-sport',
  templateUrl: './home-sport.component.html',
  styleUrl: './home-sport.component.css'
})
export class HomeSportComponent {

}
