import { TrimDirective } from './trim.directive';

describe('TrimDirective', () => {
  it('should create an instance', () => {
    const directive = new TrimDirective();
    expect(directive).toBeTruthy();
  });
});
