import { Component } from '@angular/core';



@Component({
  selector: 'app-banner-header',
  templateUrl: './banner-header.component.html',
  styleUrl: './banner-header.component.css'
})
export class BannerHeaderComponent {

  constructor(){

  }

}
